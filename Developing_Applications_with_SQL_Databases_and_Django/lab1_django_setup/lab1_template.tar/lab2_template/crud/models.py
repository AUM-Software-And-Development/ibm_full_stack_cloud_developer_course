from django.db import models
from django.utils.timezone import now

# Define your models from here:

