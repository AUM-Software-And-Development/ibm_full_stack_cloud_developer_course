from django.db import models
from django.utils.timezone import now

# Define your models from here:

# User model
class User(models.Model):
    #Varchar
    first_name = models.CharField(null=False, max_length=30, default='john')
    #Varchar
    last_name = models.CharField(null=False, max_length=30, default='doe')
    dob = models.DateField(null=True)

    # A to string method
    def __str__(self):
        return self.first_name + " " + self.last_name

# Instructor model
class Instructor(User):
    #Bit/Bool
    full_time = models.BooleanField(default=True)
    #Int
    total_learners = models.IntegerField()

    def __str__(self):
        return "First name: " + self.first_name + ", " + \
                "Last name: " + self.last_name + ", " + \
                "Is full time: " + str(self.full_time) + ", " + \
                "Total Learners: " + str(self.total_learners)
                